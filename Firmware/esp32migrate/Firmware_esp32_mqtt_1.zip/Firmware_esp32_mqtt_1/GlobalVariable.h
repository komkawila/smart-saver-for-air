float temperature = 0.0f;
float old_temp = 0.00f;
float slope = 0.00f;

bool _first = true;

int times = 0;
//int times_No1 = 0; // Time No.1 Back
//int times_No2 = 0; // Time No.2 Start
//int times_No3 = 0; // Time No.3 End
int pulse = 0; // Pulse
int sleeps = 0; // Pulse

float minTemps = 0.00f;
float maxTemps = 0.00f;
float avgTemps = 0.00f;

int ledlogo = 0;

bool _sleep = false; // // สถานะ sleep mode
int countnew = 0;
